"""Paso 2: lista de especies de aves (GBIF Backbone) + nombres vernáculos."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from common import connect, http, log, GBIF, BACKBONE

LANGS = {"eng": "en", "spa": "es", "por": "pt", "fra": "fr", "deu": "de"}


def ingest_taxa(con, s):
    offset, total = 0, 0
    while True:
        r = s.get(f"{GBIF}/species/search", timeout=60, params={
            "datasetKey": BACKBONE, "highertaxonKey": 212,  # 212 = Aves
            "rank": "SPECIES", "status": "ACCEPTED", "limit": 1000, "offset": offset}).json()
        rows = [(x["key"], x.get("scientificName"), x.get("canonicalName"),
                 x.get("genus"), x.get("family"), x.get("order"))
                for x in r.get("results", []) if x.get("key")]
        with con.cursor() as cur:
            cur.executemany("""INSERT INTO taxa (taxon_key, scientific_name, canonical_name, genus, family, "order")
                               VALUES (%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""", rows)
        con.commit()
        total += len(rows)
        offset += 1000
        log.info("Especies leídas: %d", total)
        if r.get("endOfRecords") or not rows:
            break


def fetch_vern(s, key):
    out = set()
    r = s.get(f"{GBIF}/species/{key}/vernacularNames", params={"limit": 300}, timeout=60).json()
    for v in r.get("results", []):
        lang, name = LANGS.get(v.get("language")), v.get("vernacularName")
        if lang and name:
            out.add((key, lang, name.strip()[:200], (v.get("source") or "gbif")[:100]))
    return key, out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-vernacular", action="store_true")
    ap.add_argument("--workers", type=int, default=8)
    a = ap.parse_args()
    con, s = connect(), http()
    ingest_taxa(con, s)
    if a.skip_vernacular:
        return
    done = {r[0] for r in con.execute("SELECT key FROM ingest_progress WHERE task='vernacular'")}
    todo = [r[0] for r in con.execute("SELECT taxon_key FROM taxa") if str(r[0]) not in done]
    with ThreadPoolExecutor(a.workers) as ex:
        futs = [ex.submit(fetch_vern, s, k) for k in todo]
        for f in tqdm(as_completed(futs), total=len(futs), desc="nombres vernáculos"):
            try:
                key, rows = f.result()
            except Exception as e:
                log.warning("fallo vernáculos: %s", e)
                continue
            with con.cursor() as cur:
                cur.executemany("""INSERT INTO vernacular_names (taxon_key, language, name, source)
                                   VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING""", list(rows))
                cur.execute("INSERT INTO ingest_progress (task,key) VALUES ('vernacular',%s) ON CONFLICT DO NOTHING", (str(key),))
            con.commit()


if __name__ == "__main__":
    main()
