"""Paso 1: crea el esquema en PostgreSQL (idempotente)."""
import pathlib
from common import connect, log

sql = (pathlib.Path(__file__).parent / "sql" / "schema.sql").read_text()
with connect() as con:
    con.execute(sql)
log.info("Esquema creado/actualizado.")
