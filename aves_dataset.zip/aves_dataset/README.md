# Dataset multimodal de aves (imagen, audio, texto, coordenadas)

Pipeline reproducible que arma un dataset propio a partir de fuentes abiertas, guardando **metadatos en
PostgreSQL/PostGIS** y **medios comprimidos** (WebP 512 px, OGG mono 32 kHz ≤30 s) para que el tamaño
total se mantenga pequeño.

## Fuentes
| Modalidad | Fuente | Licencia |
|---|---|---|
| Taxonomía y nombres | GBIF Backbone | CC0 / CC-BY |
| Imágenes | iNaturalist (vía GBIF), solo CC0 y CC-BY | por archivo |
| Audio | Xeno-canto + iNaturalist (vía GBIF) | por archivo (XC usa muchas NC) |
| Texto | Wikipedia en/es (introducción) | CC-BY-SA-4.0 |
| Clima/altitud | WorldClim 2.1 (10 arcmin) | CC-BY 4.0 |

## Puesta en marcha
```bash
cp .env.example .env        # edita USER_AGENT (contacto real) y OBSERVER_SALT (secreta)
docker compose up -d
pip install -r requirements.txt   # ffmpeg debe estar en el PATH

python 01_init_db.py
python 02_taxonomy.py
python 03_occurrences.py --media image --max-taxa 20     # piloto; quita --max-taxa para todo
python 03_occurrences.py --media audio --max-taxa 20
python 04_texts.py
python 05_download_media.py --type image
python 05_download_media.py --type audio
python 06_quality.py
python 07_pairs_and_splits.py
python 08_environment.py --download
python 10_annotate_import.py --make-sheet hoja.csv --n 200   # opcional: validar ruido a mano
python 09_export.py                                          # --exclude-nc para uso comercial
```
Todos los pasos son reanudables (progreso en `ingest_progress` y `media.download_status`).
Recomendación: corre primero el piloto con `--max-taxa 20` y revisa el tamaño en disco antes de escalar.

## Qué obtienes
`DATA_DIR/export/*.parquet` (taxa, observations con covariables y splits, media con métricas de calidad,
texts, pairs, annotations) + `manifest.json` + `ATTRIBUTION.csv`. Archivos en `DATA_DIR/images` y `DATA_DIR/audio`.

## Decisiones de diseño y límites
- **Muestreo estratificado** por continente, máx. 2 registros por observador: reduce sesgo geográfico y de observador.
- **Pares imagen-audio**: `same_observation` (confianza 1.0) y `spatiotemporal` (misma especie, ≤5 km, ≤7 días; son
  *pseudo-pares*, no la misma ave; usa `confidence`).
- **Splits sin fuga**: `split_observer` (por observador anonimizado) y `split_geo` (bloques de 5°). Para evaluar
  generalización geográfica usa `split_geo`.
- **Ruido**: las banderas de `media_quality` son heurísticas (el "SNR" es un proxy). Valídalas con `annotations`.
- **Privacidad**: observadores con hash salado; especies CR/EN o con datos generalizados salen con coordenadas a 0.1°.
- **Licencias**: respeta cada licencia; el audio de Xeno-canto suele ser NC/SA. Atribución en `ATTRIBUTION.csv`.
- Las claves de dataset de GBIF y la URL de WorldClim pueden cambiar: verifícalas si un paso devuelve 0 resultados.
