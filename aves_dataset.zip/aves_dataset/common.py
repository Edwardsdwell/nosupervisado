"""Utilidades compartidas: conexión, HTTP con reintentos, licencias, rutas."""
import os, re, hashlib, pathlib, logging
import psycopg, requests
from dotenv import load_dotenv
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://aves:aves@localhost:5432/aves")
DATA_DIR = pathlib.Path(os.getenv("DATA_DIR", "./data")).resolve()
USER_AGENT = os.getenv("USER_AGENT", "aves-dataset/0.1 (cambia-esto@ejemplo.com)")
OBSERVER_SALT = os.getenv("OBSERVER_SALT", "cambia-esta-sal")
IMG_MAX_SIDE = int(os.getenv("IMG_MAX_SIDE", "512"))
AUDIO_MAX_SECONDS = int(os.getenv("AUDIO_MAX_SECONDS", "30"))
AUDIO_FORMAT = os.getenv("AUDIO_FORMAT", "ogg")  # ogg (ligero) | flac (sin pérdida, pesado)

GBIF = "https://api.gbif.org/v1"
# Claves de dataset en GBIF (verifícalas en gbif.org/dataset/<clave> si algo no devuelve resultados)
BACKBONE = "d7dddbf4-2cf0-4f39-9b2a-bb099caae36c"      # GBIF Backbone Taxonomy
INAT_DATASET = "50c9509d-22c7-4a22-a47d-8c48425ef4a7"  # iNaturalist Research-grade Observations
XC_DATASET = "b1047888-ae52-4179-9dd5-5448ea342a24"    # Xeno-canto

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("aves")


def connect(autocommit=False):
    return psycopg.connect(DATABASE_URL, autocommit=autocommit)


def http(pool=16):
    s = requests.Session()
    s.headers["User-Agent"] = USER_AGENT
    retry = Retry(total=5, backoff_factor=1.0, status_forcelist=(429, 500, 502, 503, 504),
                  allowed_methods=("GET", "HEAD"), respect_retry_after_header=True)
    ad = HTTPAdapter(max_retries=retry, pool_connections=pool, pool_maxsize=pool)
    s.mount("https://", ad)
    s.mount("http://", ad)
    return s


def observer_hash(name: str) -> str:
    return hashlib.sha256((OBSERVER_SALT + name).encode()).hexdigest()[:16]


def normalize_license(v):
    """Devuelve 'CC0-1.0', 'CC-BY-4.0', 'CC-BY-NC-SA-4.0'... o None si no es una licencia abierta reconocible."""
    if not v:
        return None
    low = str(v).strip().lower()
    if "publicdomain/zero" in low or low in ("cc0_1_0", "cc0", "cc0-1.0"):
        return "CC0-1.0"
    m = re.search(r"licenses/([a-z\-]+)/(\d\.\d)", low)
    if m:
        return f"CC-{m.group(1).upper()}-{m.group(2)}"
    m = re.match(r"cc_([a-z_]+?)_(\d_\d)$", low)
    if m:
        return f"CC-{m.group(1).upper().replace('_', '-')}-{m.group(2).replace('_', '.')}"
    return None


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()
