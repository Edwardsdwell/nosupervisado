"""Paso 5: descarga y comprime medios (streaming, reanudable, sin cargar nada grande en RAM).

Imágenes -> WebP, lado máx IMG_MAX_SIDE.  Audio -> mono 32 kHz, máx AUDIO_MAX_SECONDS, OGG Vorbis (o FLAC).
Requiere ffmpeg en el PATH para el audio.
"""
import argparse, io, os, subprocess, tempfile, pathlib
from concurrent.futures import ThreadPoolExecutor
import psycopg, soundfile as sf
from PIL import Image, ImageOps
from common import (connect, http, log, sha256_file, DATA_DIR, IMG_MAX_SIDE,
                    AUDIO_MAX_SECONDS, AUDIO_FORMAT)

S = http(32)
MAX_IMG_BYTES, MAX_AUDIO_BYTES = 30 * 2**20, 60 * 2**20

CLAIM = """
WITH c AS (SELECT media_id FROM media WHERE download_status='pending' AND type=%s AND attempts<3
           ORDER BY media_id LIMIT %s FOR UPDATE SKIP LOCKED)
UPDATE media m SET download_status='working', attempts=m.attempts+1 FROM c WHERE m.media_id=c.media_id
RETURNING m.media_id, m.url_original, (SELECT taxon_key FROM observations o WHERE o.obs_id=m.obs_id)"""


def get_bytes(url, limit):
    buf, n = io.BytesIO(), 0
    with S.get(url, stream=True, timeout=(10, 60)) as r:
        r.raise_for_status()
        for ch in r.iter_content(1 << 16):
            n += len(ch)
            if n > limit:
                raise ValueError("archivo demasiado grande")
            buf.write(ch)
    buf.seek(0)
    return buf


def do_image(media_id, url, taxon):
    urls = [url]
    if "inaturalist-open-data" in url and "/original." in url:  # ahorra ancho de banda (1024 px)
        urls = [url.replace("/original.", "/large."), url]
    buf, last = None, None
    for u in urls:
        try:
            buf = get_bytes(u, MAX_IMG_BYTES)
            break
        except Exception as e:
            last = e
    if buf is None:
        raise last
    im = ImageOps.exif_transpose(Image.open(buf)).convert("RGB")
    im.thumbnail((IMG_MAX_SIDE, IMG_MAX_SIDE), Image.LANCZOS)
    rel = f"images/{taxon}/{media_id}.webp"
    path = DATA_DIR / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path, "WEBP", quality=85, method=4)
    return dict(file_path=rel, sha=sha256_file(path), bytes=path.stat().st_size,
                width=im.width, height=im.height, duration=None, sr=None)


def do_audio(media_id, url, taxon):
    ext = pathlib.Path(url.split("?")[0]).suffix or ".bin"
    tmp = tempfile.NamedTemporaryFile(suffix=ext, delete=False)
    try:
        n = 0
        with S.get(url, stream=True, timeout=(10, 60)) as r:
            r.raise_for_status()
            for ch in r.iter_content(1 << 16):
                n += len(ch)
                if n > MAX_AUDIO_BYTES:
                    raise ValueError("audio demasiado grande")
                tmp.write(ch)
        tmp.close()
        out_ext = "ogg" if AUDIO_FORMAT == "ogg" else "flac"
        rel = f"audio/{taxon}/{media_id}.{out_ext}"
        path = DATA_DIR / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", tmp.name, "-t", str(AUDIO_MAX_SECONDS),
               "-vn", "-ac", "1", "-ar", "32000"]
        cmd += ["-c:a", "libvorbis", "-q:a", "3"] if out_ext == "ogg" else ["-c:a", "flac"]
        subprocess.run(cmd + [str(path)], check=True, capture_output=True, timeout=300)
        info = sf.info(str(path))
        return dict(file_path=rel, sha=sha256_file(path), bytes=path.stat().st_size,
                    width=None, height=None, duration=info.duration, sr=info.samplerate)
    finally:
        os.unlink(tmp.name)


def work(args):
    kind, media_id, url, taxon = args
    try:
        res = (do_image if kind == "image" else do_audio)(media_id, url, taxon)
        return media_id, res, None
    except Exception as e:
        return media_id, None, str(e)[:300]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--type", choices=["image", "audio"], required=True)
    ap.add_argument("--workers", type=int, default=16)
    ap.add_argument("--batch", type=int, default=500)
    ap.add_argument("--max-items", type=int, default=None)
    a = ap.parse_args()
    con = connect()
    con.execute("UPDATE media SET download_status='pending' WHERE download_status='working'")
    con.commit()
    total = 0
    with ThreadPoolExecutor(a.workers) as ex:
        while True:
            rows = con.execute(CLAIM, (a.type, a.batch)).fetchall()
            con.commit()
            if not rows:
                break
            for media_id, res, err in ex.map(work, [(a.type, *r) for r in rows]):
                if err:
                    con.execute("""UPDATE media SET error=%s,
                        download_status=CASE WHEN attempts>=3 THEN 'failed' ELSE 'pending' END WHERE media_id=%s""",
                                (err, media_id))
                else:
                    try:
                        con.execute("""UPDATE media SET download_status='ok', file_path=%s, sha256=%s, bytes=%s,
                            width=%s, height=%s, duration_s=%s, sample_rate=%s, error=NULL WHERE media_id=%s""",
                                    (res["file_path"], res["sha"], res["bytes"], res["width"], res["height"],
                                     res["duration"], res["sr"], media_id))
                    except psycopg.errors.UniqueViolation:
                        con.rollback()
                        (DATA_DIR / res["file_path"]).unlink(missing_ok=True)
                        con.execute("UPDATE media SET download_status='duplicate', sha256=NULL WHERE media_id=%s",
                                    (media_id,))
                con.commit()
            total += len(rows)
            log.info("Procesados: %d", total)
            if a.max_items and total >= a.max_items:
                break


if __name__ == "__main__":
    main()
